﻿using System;
using Primero.App.Dominio;


namespace Primero.App.Consola
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
