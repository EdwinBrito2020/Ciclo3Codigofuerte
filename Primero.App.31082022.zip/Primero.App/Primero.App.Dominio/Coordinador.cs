using System;

namespace Primero.App.Dominio
{
    public class Coordinador:Persona
    {
        public int Password{get;set;}
        public string Roll{get;set;}
    }
}