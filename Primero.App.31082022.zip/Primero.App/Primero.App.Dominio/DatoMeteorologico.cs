using System;

namespace Primero.App.Dominio
{
    public class DatoMeteorologico
    {
        public int Id{get;set;}
        public string FechaHora{get;set;}
        public float Valor{get;set;}
        public string Tipo{get;set;}
        

    }
}