﻿using System;

namespace Primero.App.Persistencia
{
    public class Class1
    {
    }
}
