using System;
using Primero.App.Dominio;

namespace Primero.App.Persistencia
{
    public interface IRepositorioReporte
    {
        Coordinador AddReporte(Reporte reporte);
        Coordinador UpdateCoordinador(Coordinador coordinador);
        void DeleteReportexId(int id);
        Reporte GetReportexId(int id);

    }
}