using System;
using Primero.App.Dominio;

namespace Primero.App.Persistencia
{
    public interface IRepositorioCoordinador
    {
        Coordinador AddCoordinador(Coordinador coordinador);
        Coordinador UpdateCoordinador(Coordinador coordinador);
        void DeleteCoordinadorxId(int id);
        Coordinador GetCoordinadorxId(int id);

    }
}